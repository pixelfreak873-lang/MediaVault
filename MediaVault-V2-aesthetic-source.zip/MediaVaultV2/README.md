# Media Vault — V2 UI Build

This version rebuilds the app UI around the Media Vault dark/neon-blue design mockup:
- Home
- Downloads
- Tools
- Settings
- Premium entry point
- Dark glass/card styling
- Blue action buttons
- Quick-action grid
- Download queue UI

## Downloader foundation

The project includes the free `yt-dlp-android` library (`2.0.2`) and FFmpeg maintained Android library (`8.1.9`) as dependencies.

The downloader uses:
- `YtDlp.init(context)`
- `YtDlpRequest`
- best video/audio selection with MP4 merge
- WorkManager for queued/background work
- MediaStore export to `Download/MediaVault` on Android 10+

The current UI build is intentionally focused on the shell and first downloader flow. The individual converter screens are visual/interaction placeholders and will be wired to FFmpeg in the next implementation pass.

## Open the project

1. Extract this ZIP.
2. Open the `MediaVaultV2` folder in Android Studio.
3. Let Gradle sync finish.
4. Connect an Android phone with USB debugging enabled.
5. Press Run.

## Important

This is source code, not a prebuilt APK. The exact build should be verified in Android Studio on the computer you use. If Gradle reports an error, send the error/screenshot and the project can be corrected from there.

The yt-dlp Android library currently documents Maven Central dependency `dev.ffmpegkit-maintained:yt-dlp-android:2.0.2` and Android 7+ requirements. Its bundled runtime is large, so expect the APK/AAB to be substantially larger than a normal Compose app.

Media Vault should only be used to download or process media you are authorized to access.
