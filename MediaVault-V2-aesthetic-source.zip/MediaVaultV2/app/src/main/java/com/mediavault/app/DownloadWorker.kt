package com.mediavault.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dev.ffmpegkit.ytdlp.YtDlp
import dev.ffmpegkit.ytdlp.YtDlpRequest
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

class DownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val url = inputData.getString(KEY_URL)?.trim().orEmpty()
        if (url.isBlank()) return Result.failure()

        val staging = File(
            applicationContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
            "MediaVault"
        ).apply { mkdirs() }

        val output = File(staging, "%(title)s.%(ext)s").absolutePath
        val request = YtDlpRequest(url)
            .setOutputTemplate(output)
            .addOption("-f", "bv*+ba/b")
            .addOption("--merge-output-format", "mp4")
            .addOption("--no-playlist")

        val finished = suspendCancellableCoroutine<Boolean> { continuation ->
            try {
                YtDlp.executeAsync(request) { progress, _, line ->
                    setProgressAsync(
                        androidx.work.workDataOf(
                            "progress" to progress,
                            "line" to line
                        )
                    )

                    if (!continuation.isCompleted) {
                        when {
                            progress >= 100.0 -> continuation.resume(true)
                            line.contains("ERROR:", ignoreCase = true) ->
                                continuation.resume(false)
                        }
                    }
                }
            } catch (_: Exception) {
                if (!continuation.isCompleted) continuation.resume(false)
            }
        }

        if (!finished) return Result.failure()

        val produced = staging.listFiles()
            ?.filter { it.isFile && it.extension.equals("mp4", true) }
            ?.maxByOrNull { it.lastModified() }
            ?: return Result.failure()

        return if (publishToDownloads(produced)) {
            Result.success()
        } else {
            Result.failure()
        }
    }

    private fun publishToDownloads(file: File): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                    put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/MediaVault"
                    )
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }

                val resolver = applicationContext.contentResolver
                val uri: Uri = resolver.insert(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    values
                ) ?: return false

                resolver.openOutputStream(uri)?.use { out ->
                    file.inputStream().use { input -> input.copyTo(out) }
                }

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                true
            } else {
                // Android 9 and below: keep the result in app-private Downloads.
                // A later storage layer can add legacy public-folder export.
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        const val KEY_URL = "url"
    }
}
