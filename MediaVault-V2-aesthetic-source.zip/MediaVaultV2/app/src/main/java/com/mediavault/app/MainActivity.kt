package com.mediavault.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Workspaces
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.mediavault.app.ui.MediaVaultTheme
import java.util.UUID

private val Blue = Color(0xFF2387FF)
private val ElectricBlue = Color(0xFF38A5FF)
private val Purple = Color(0xFF8A5CFF)
private val Background = Color(0xFF050B14)
private val SurfaceDark = Color(0xFF0B1625)
private val SurfaceDark2 = Color(0xFF0E1C2D)
private val Muted = Color(0xFF8EA2BA)

enum class Tab(val label: String) {
    HOME("Home"),
    DOWNLOADS("Downloads"),
    TOOLS("Tools"),
    SETTINGS("Settings")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MediaVaultTheme {
                MediaVaultApp()
            }
        }
    }
}

@Composable
fun MediaVaultApp() {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var url by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    Scaffold(
        containerColor = Background,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF07111E),
                tonalElevation = 0.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Tab.values().forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                when (item) {
                                    Tab.HOME -> Icons.Default.Home
                                    Tab.DOWNLOADS -> Icons.Default.Download
                                    Tab.TOOLS -> Icons.Default.Build
                                    Tab.SETTINGS -> Icons.Default.Settings
                                },
                                contentDescription = item.label
                            )
                        },
                        label = { Text(item.label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            AnimatedContent(targetState = tab, label = "tab") { current ->
                when (current) {
                    Tab.HOME -> HomeScreen(
                        url = url,
                        onUrlChange = { url = it },
                        onDownload = {
                            if (url.isBlank()) {
                                notice = "Paste a video or audio link first."
                            } else {
                                val request = OneTimeWorkRequestBuilder<DownloadWorker>()
                                    .setInputData(workDataOf(DownloadWorker.KEY_URL to url))
                                    .addTag("media-download")
                                    .build()
                                WorkManager.getInstance(
                                    androidx.compose.ui.platform.LocalContext.current
                                ).enqueue(request)
                                notice = "Download added to your queue."
                                tab = Tab.DOWNLOADS
                            }
                        },
                        notice = notice,
                        onClearNotice = { notice = "" },
                        onTools = { tab = Tab.TOOLS }
                    )
                    Tab.DOWNLOADS -> DownloadsScreen()
                    Tab.TOOLS -> ToolsScreen()
                    Tab.SETTINGS -> SettingsScreen(onPremium = { notice = "Premium screen coming next." })
                }
            }
        }
    }
}

@Composable
private fun AppHeader(title: String, premium: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            color = Color.White,
            fontSize = 25.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.weight(1f))
        if (premium) {
            Icon(
                Icons.Outlined.Star,
                contentDescription = "Premium",
                tint = Color(0xFFFFC83D),
                modifier = Modifier.size(23.dp)
            )
        }
        IconButton(onClick = {}) {
            Icon(Icons.Outlined.MoreVert, null, tint = Muted)
        }
    }
}

@Composable
private fun HomeScreen(
    url: String,
    onUrlChange: (String) -> Unit,
    onDownload: () -> Unit,
    notice: String,
    onClearNotice: () -> Unit,
    onTools: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AppHeader("Media Vault", premium = true)
        }

        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                VaultGradientCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Link, null, tint = ElectricBlue)
                        TextField(
                            value = url,
                            onValueChange = onUrlChange,
                            placeholder = { Text("Paste video or audio link...", color = Muted) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        if (url.isNotEmpty()) {
                            IconButton(onClick = { onUrlChange("") }) {
                                Icon(Icons.Default.Close, null, tint = Muted)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Button(
                    onClick = onDownload,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Blue)
                ) {
                    Icon(Icons.Default.Download, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Download", fontWeight = FontWeight.Bold)
                }

                if (notice.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF10253A)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF53E0A1))
                            Spacer(Modifier.size(8.dp))
                            Text(notice, color = Color.White, modifier = Modifier.weight(1f))
                            IconButton(onClick = onClearNotice) {
                                Icon(Icons.Default.Close, null, tint = Muted)
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionTitle("Quick Actions")
        }

        item {
            Row(
                Modifier.padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickAction("Video → MP3", Icons.Default.MusicNote, Purple, Modifier.weight(1f)) {}
                QuickAction("Video → GIF", Icons.Default.VideoFile, Blue, Modifier.weight(1f)) {}
            }
        }

        item {
            Row(
                Modifier.padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickAction("Compress Video", Icons.Default.Workspaces, Color(0xFF5B6CFF), Modifier.weight(1f)) {}
                QuickAction("Extract Subtitles", Icons.Default.Subtitles, Color(0xFFAA55FF), Modifier.weight(1f)) {}
            }
        }

        item {
            SectionTitle("Recent Downloads", "View All")
        }

        item {
            RecentMediaCard("sunroof.mp4", "1280p  •  12.4 MB", "Just now", Icons.Default.VideoFile)
        }

        item {
            RecentMediaCard("Anime_Opening.mp4", "1080p  •  45.2 MB", "12 min ago", Icons.Default.VideoFile)
        }

        item {
            RecentMediaCard("Nature_Scenery.mp4", "720p  •  5.3 MB", "32 min ago", Icons.Default.VideoFile)
        }
    }
}

@Composable
private fun DownloadsScreen() {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        item { AppHeader("Downloads") }
        item {
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Active", "Completed", "Failed").forEachIndexed { index, label ->
                    FilterChip(label, selected = index == 0)
                }
            }
        }
        item { SectionTitle("Active Downloads") }
        item { ActiveDownloadCard() }
        item { SectionTitle("Completed") }
        items(
            listOf(
                "sunroof.mp4" to "1280p  •  12.4 MB",
                "Nature_Scenery.mp4" to "720p  •  5.3 MB",
                "song.mp3" to "192 kbps  •  3.2 MB"
            )
        ) { (name, meta) ->
            RecentMediaCard(name, meta, "Completed", Icons.Default.PlayArrow)
        }
        item { SectionTitle("Failed") }
        item {
            RecentMediaCard("game_video.mp4", "Network error", "Retry", Icons.Default.Close, failed = true)
        }
    }
}

@Composable
private fun ToolsScreen() {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        item { AppHeader("Tools") }
        item { SectionTitle("Conversion Tools") }
        item {
            ToolRow("Video → MP3", "Extract audio from video", Icons.Default.MusicNote, Purple)
            ToolRow("Video → GIF", "Convert video to GIF", Icons.Default.VideoFile, Blue)
            ToolRow("Image → WebP", "Convert image to WebP", Icons.Default.Image, Color(0xFF35C989))
            ToolRow("WebP → PNG/JPEG", "Convert WebP to PNG or JPEG", Icons.Default.Image, Blue)
        }
        item { SectionTitle("Compression Tools") }
        item {
            ToolRow("Video Compressor", "Reduce video file size", Icons.Default.Workspaces, Color(0xFF715BFF))
        }
        item { SectionTitle("Subtitle Tools") }
        item {
            ToolRow("Extract Subtitles", "Save available subtitles as SRT", Icons.Default.Subtitles, Color(0xFFA652FF))
        }
    }
}

@Composable
private fun SettingsScreen(onPremium: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        item { AppHeader("Settings") }
        item {
            Card(
                Modifier.padding(horizontal = 20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark2),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.AutoAwesome, null, tint = ElectricBlue)
                        Spacer(Modifier.size(12.dp))
                        Column {
                            Text("Media Vault", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Version 2.0", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        item { SectionTitle("General") }
        item { SettingRow("Download Location", "/storage/emulated/0/Download/MediaVault", Icons.Default.Folder) }
        item { SettingRow("Default Quality", "1080p (HD)", Icons.Default.VideoFile) }
        item { SettingRow("Appearance", "Dark Mode", Icons.Default.Palette) }
        item { SettingRow("Download Preferences", "Best available", Icons.Default.Download) }
        item { SettingRow("Notifications", "Enabled", Icons.Default.CloudDownload) }
        item { SectionTitle("Premium") }
        item {
            Card(
                Modifier.padding(horizontal = 20.dp).clickable(onClick = onPremium),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101D2F)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Star, null, tint = Color(0xFFFFC83D), modifier = Modifier.size(28.dp))
                    Spacer(Modifier.size(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Upgrade to Premium", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("More downloads, all tools, no ads", color = Muted, fontSize = 12.sp)
                    }
                    Text("›", color = ElectricBlue, fontSize = 28.sp)
                }
            }
        }
        item { SettingRow("About Media Vault", "Made for local media processing", Icons.Outlined.AutoAwesome) }
    }
}

@Composable
private fun SectionTitle(title: String, action: String? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.weight(1f))
        if (action != null) Text(action, color = ElectricBlue, fontSize = 12.sp)
    }
}

@Composable
private fun VaultGradientCard(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0D1D30), Color(0xFF0A1422))))
            .border(1.dp, Color(0xFF193A5E), RoundedCornerShape(16.dp))
            .padding(5.dp)
    ) {
        content()
    }
}

@Composable
private fun QuickAction(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(15.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun RecentMediaCard(
    name: String,
    meta: String,
    time: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    failed: Boolean = false
) {
    Card(
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(
                    if (failed) Color(0xFF3A1620) else Color(0xFF112A43)
                ),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = if (failed) Color(0xFFFF5D70) else ElectricBlue)
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(meta, color = if (failed) Color(0xFFFF5D70) else Muted, fontSize = 11.sp)
            }
            Text(time, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ActiveDownloadCard() {
    Card(
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF122A46)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.VideoFile, null, tint = ElectricBlue)
                }
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Anime_Opening.mp4", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("45.2 MB  •  38%", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.Close, null, tint = Muted)
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { 0.38f },
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(5.dp)),
                color = Blue,
                trackColor = Color(0xFF1C2B3E)
            )
            Spacer(Modifier.height(5.dp))
            Text("2.4 MB/s", color = ElectricBlue, fontSize = 10.sp)
        }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean) {
    Surface(
        color = if (selected) Blue else SurfaceDark2,
        shape = RoundedCornerShape(50)
    ) {
        Text(label, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp))
    }
}

@Composable
private fun ToolRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color) {
    Card(
        Modifier.padding(horizontal = 20.dp, vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(15.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = tint)
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
            Text("›", color = Muted, fontSize = 24.sp)
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Muted)
            Spacer(Modifier.size(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Medium)
                Text(subtitle, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("›", color = Muted, fontSize = 24.sp)
        }
    }
}
