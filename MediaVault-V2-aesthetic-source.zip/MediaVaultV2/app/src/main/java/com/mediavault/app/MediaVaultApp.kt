package com.mediavault.app

import android.app.Application
import dev.ffmpegkit.ytdlp.YtDlp

class MediaVaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            YtDlp.init(this)
        } catch (_: Exception) {
            // The downloader screen remains usable; the engine error will be
            // surfaced when a download is attempted.
        }
    }
}
