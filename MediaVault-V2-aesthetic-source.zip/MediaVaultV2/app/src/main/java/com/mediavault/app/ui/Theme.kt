package com.mediavault.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MediaVaultColors = darkColorScheme(
    primary = Color(0xFF2387FF),
    secondary = Color(0xFF8A5CFF),
    tertiary = Color(0xFF38A5FF),
    background = Color(0xFF050B14),
    surface = Color(0xFF0B1625),
    surfaceVariant = Color(0xFF0E1C2D),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun MediaVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MediaVaultColors,
        content = content
    )
}
